import React from 'react';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const SettingsPanel = ({ settings, setSettings }) => {
  const updateSetting = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="grid grid-cols-2 gap-4 mb-6">
      <div>
        <label className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-2">
          <SafeIcon icon={FiIcons.FiMaximize} /> Aspect Ratio
        </label>
        <select 
          value={settings.aspect_ratio}
          onChange={(e) => updateSetting('aspect_ratio', e.target.value)}
          className="w-full glass-input py-2 text-sm"
        >
          <option value="16:9">16:9 (Landscape)</option>
          <option value="9:16">9:16 (Portrait)</option>
          <option value="1:1">1:1 (Square)</option>
        </select>
      </div>
      <div>
        <label className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-2">
          <SafeIcon icon={FiIcons.FiClock} /> Duration
        </label>
        <select 
          value={settings.duration}
          onChange={(e) => updateSetting('duration', e.target.value)}
          className="w-full glass-input py-2 text-sm"
        >
          <option value="5">5 Seconds</option>
          <option value="10">10 Seconds</option>
        </select>
      </div>
      <div>
        <label className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-2">
          <SafeIcon icon={FiIcons.FiCamera} /> Camera Motion
        </label>
        <select 
          value={settings.camera}
          onChange={(e) => updateSetting('camera', e.target.value)}
          className="w-full glass-input py-2 text-sm"
        >
          <option value="none">Auto</option>
          <option value="pan_left">Pan Left</option>
          <option value="pan_right">Pan Right</option>
          <option value="zoom_in">Zoom In</option>
          <option value="zoom_out">Zoom Out</option>
        </select>
      </div>
      <div>
        <label className="flex items-center gap-2 text-xs font-medium text-slate-400 mb-2">
          <SafeIcon icon={FiIcons.FiStar} /> Quality
        </label>
        <select 
          value={settings.quality}
          onChange={(e) => updateSetting('quality', e.target.value)}
          className="w-full glass-input py-2 text-sm"
        >
          <option value="standard">Standard HD</option>
          <option value="high">Ultra 4K</option>
        </select>
      </div>
    </div>
  );
};

export default SettingsPanel;