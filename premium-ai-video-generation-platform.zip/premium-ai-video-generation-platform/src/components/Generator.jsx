import React, { useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

import ModelSelector from './ModelSelector';
import PromptBox from './PromptBox';
import UploadPanel from './UploadPanel';
import SettingsPanel from './SettingsPanel';
import LoadingScreen from './LoadingScreen';
import VideoPreview from './VideoPreview';

const Generator = () => {
  const [prompt, setPrompt] = useState('');
  const [file, setFile] = useState(null);
  const [model, setModel] = useState('kling');
  const [settings, setSettings] = useState({
    aspect_ratio: '16:9',
    duration: '5',
    camera: 'none',
    quality: 'standard'
  });
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState(null);
  const [error, setError] = useState(null);

  const handleGenerate = async () => {
    if (!prompt) {
      setError("Please enter a prompt to generate a video.");
      return;
    }

    setIsGenerating(true);
    setError(null);
    setVideoUrl(null);

    try {
      const formData = new FormData();
      formData.append('prompt', prompt);
      formData.append('model', model);
      formData.append('settings', JSON.stringify(settings));
      if (file) {
        formData.append('image', file);
      }

      const response = await axios.post('/api/video/generate', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (response.data.success) {
        setVideoUrl(response.data.data.videoUrl);
      } else {
        setError(response.data.error || "Generation failed.");
      }
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.error || "An error occurred during generation. Check API configuration.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 pb-24">
      <div className="grid lg:grid-cols-12 gap-8">
        
        {/* Left Column: Controls */}
        <motion.div 
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="lg:col-span-5 space-y-6"
        >
          <div className="glass-panel p-6">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
              <SafeIcon icon={FiIcons.FiSettings} className="text-sky-400" />
              Generation Parameters
            </h2>
            
            <ModelSelector selectedModel={model} onSelect={setModel} />
            <PromptBox prompt={prompt} setPrompt={setPrompt} />
            <UploadPanel file={file} setFile={setFile} />
            <SettingsPanel settings={settings} setSettings={setSettings} />

            {error && (
              <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-start gap-3">
                <SafeIcon icon={FiIcons.FiAlertCircle} className="mt-0.5 shrink-0 text-lg" />
                <p>{error}</p>
              </div>
            )}

            <button 
              onClick={handleGenerate}
              disabled={isGenerating || !prompt}
              className={`w-full btn-primary py-4 text-lg mt-4 ${(!prompt || isGenerating) ? 'opacity-50 cursor-not-allowed hover:scale-100 hover:shadow-glow' : ''}`}
            >
              {isGenerating ? (
                <>
                  <SafeIcon icon={FiIcons.FiLoader} className="animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <SafeIcon icon={FiIcons.FiPlay} />
                  Generate Video
                </>
              )}
            </button>
          </div>
        </motion.div>

        {/* Right Column: Preview / Loader */}
        <motion.div 
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="lg:col-span-7"
        >
          <div className="sticky top-24 h-[calc(100vh-8rem)] min-h-[500px]">
             {isGenerating ? <LoadingScreen /> : <VideoPreview videoUrl={videoUrl} />}
          </div>
        </motion.div>

      </div>
    </div>
  );
};

export default Generator;