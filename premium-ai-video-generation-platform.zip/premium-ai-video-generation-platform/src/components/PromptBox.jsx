import React from 'react';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const PromptBox = ({ prompt, setPrompt }) => {
  return (
    <div className="mb-6">
      <label className="flex items-center gap-2 text-sm font-medium text-slate-300 mb-3">
        <SafeIcon icon={FiIcons.FiEdit3} className="text-sky-400" />
        Video Prompt
      </label>
      <div className="relative">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Cinematic cyberpunk city with neon rain, flying cars, holograms and dramatic camera movement..."
          className="w-full glass-input min-h-[120px] resize-none pb-10"
        />
        <div className="absolute bottom-3 right-3 text-xs text-slate-500 flex items-center gap-1">
          <SafeIcon icon={FiIcons.FiInfo} />
          Be descriptive for best results
        </div>
      </div>
    </div>
  );
};

export default PromptBox;