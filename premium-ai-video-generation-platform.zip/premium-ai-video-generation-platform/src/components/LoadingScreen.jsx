import React from 'react';
import { motion } from 'framer-motion';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const LoadingScreen = () => {
  return (
    <div className="h-full min-h-[400px] flex flex-col items-center justify-center p-8 text-center glass-panel border-sky-500/20 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-sky-500/5 animate-pulse-slow"></div>
      
      <div className="relative flex items-center justify-center mb-8">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="w-32 h-32 rounded-full border-t-2 border-r-2 border-sky-400/80 absolute"
        />
        <motion.div 
          animate={{ rotate: -360 }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
          className="w-40 h-40 rounded-full border-b-2 border-l-2 border-blue-500/50 absolute"
        />
        <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center shadow-glow z-10">
          <SafeIcon icon={FiIcons.FiCpu} className="text-3xl text-sky-400 animate-pulse" />
        </div>
      </div>
      
      <motion.h3 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-xl font-bold text-white mb-2 tracking-wide"
      >
        Synthesizing Reality
      </motion.h3>
      
      <p className="text-slate-400 text-sm max-w-[250px] mx-auto">
        Processing neural networks and rendering cinematic frames...
      </p>

      <div className="mt-8 w-full max-w-[200px] h-1 bg-slate-800 rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-gradient-to-r from-sky-400 to-blue-600"
          initial={{ width: "0%" }}
          animate={{ width: "100%" }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>
    </div>
  );
};

export default LoadingScreen;