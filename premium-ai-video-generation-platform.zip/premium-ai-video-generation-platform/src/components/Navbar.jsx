import React from 'react';
import { motion } from 'framer-motion';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const Navbar = () => {
  return (
    <motion.nav 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 left-0 right-0 z-50 px-6 py-4"
    >
      <div className="max-w-7xl mx-auto glass-panel border-white/5 bg-slate-950/40 backdrop-blur-2xl px-6 py-3 flex items-center justify-between rounded-full">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 p-0.5 flex items-center justify-center shadow-glow">
            <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center">
              <SafeIcon icon={FiIcons.FiVideo} className="text-sky-400 text-xl" />
            </div>
          </div>
          <span className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            NOVA <span className="text-sky-400 font-light">AI</span>
          </span>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <a href="#" className="hover:text-sky-400 transition-colors">Models</a>
          <a href="#" className="hover:text-sky-400 transition-colors">Gallery</a>
          <a href="#" className="hover:text-sky-400 transition-colors">Enterprise</a>
        </div>

        <div className="flex items-center gap-4">
          <button className="text-sm font-medium text-slate-300 hover:text-white transition-colors">
            Documentation
          </button>
          <button className="btn-primary py-2 px-5 text-sm rounded-full">
            Start Creating
          </button>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navbar;