import React from 'react';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const models = [
  { id: 'kling', name: 'Kling Video', desc: 'Cinematic & Realistic' },
  { id: 'veo', name: 'Veo', desc: 'High Fidelity' },
  { id: 'wan', name: 'Wan', desc: 'Stylized Motion' },
  { id: 'pixverse', name: 'PixVerse', desc: 'Fast Generation' },
  { id: 'hunyuan', name: 'Hunyuan', desc: 'Balanced' }
];

const ModelSelector = ({ selectedModel, onSelect }) => {
  return (
    <div className="mb-6">
      <label className="flex items-center gap-2 text-sm font-medium text-slate-300 mb-3">
        <SafeIcon icon={FiIcons.FiCpu} className="text-sky-400" />
        AI Model
      </label>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {models.map((model) => (
          <button
            key={model.id}
            onClick={() => onSelect(model.id)}
            className={`p-3 rounded-xl border text-left transition-all duration-200 ${
              selectedModel === model.id
                ? 'bg-sky-500/10 border-sky-400 shadow-[0_0_15px_rgba(56,189,248,0.2)]'
                : 'bg-slate-900/50 border-slate-700 hover:border-slate-500 hover:bg-slate-800/50'
            }`}
          >
            <div className="font-medium text-white text-sm">{model.name}</div>
            <div className="text-xs text-slate-500 mt-1">{model.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ModelSelector;