import React from 'react';
import { motion } from 'framer-motion';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const Hero = () => {
  return (
    <div className="pt-32 pb-12 px-6 text-center max-w-4xl mx-auto">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-sky-500/30 bg-sky-500/10 text-sky-400 text-sm font-medium mb-6"
      >
        <SafeIcon icon={FiIcons.FiZap} />
        Powered by FAL.AI Generation Engine
      </motion.div>
      
      <motion.h1 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1, duration: 0.6 }}
        className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-6 leading-tight"
      >
        Imagine it. <br/>
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-blue-500 to-purple-500 animate-pulse-slow">
          Generate it.
        </span>
      </motion.h1>
      
      <motion.p 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="text-lg md:text-xl text-slate-400 font-light mb-10 max-w-2xl mx-auto"
      >
        Transform your text and images into cinematic masterpieces using the world's most advanced AI video models. No limits, pure creativity.
      </motion.p>
    </div>
  );
};

export default Hero;