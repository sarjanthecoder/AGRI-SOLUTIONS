import React from 'react';
import { motion } from 'framer-motion';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const VideoPreview = ({ videoUrl }) => {
  if (!videoUrl) {
    return (
      <div className="h-full min-h-[400px] flex flex-col items-center justify-center p-8 text-center glass-panel border-dashed border-slate-700/50">
        <div className="w-16 h-16 rounded-full bg-slate-800/50 flex items-center justify-center mb-4">
          <SafeIcon icon={FiIcons.FiFilm} className="text-slate-500 text-2xl" />
        </div>
        <h3 className="text-lg font-medium text-slate-300 mb-2">Awaiting Generation</h3>
        <p className="text-sm text-slate-500 max-w-xs">
          Configure your settings and hit generate to see your AI masterpiece here.
        </p>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-panel overflow-hidden relative group h-full flex flex-col"
    >
      <div className="bg-slate-900 border-b border-white/5 p-3 flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-sky-400 font-medium">
          <div className="w-2 h-2 rounded-full bg-sky-400 shadow-glow animate-pulse"></div>
          Generation Complete
        </div>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors">
            <SafeIcon icon={FiIcons.FiMaximize2} />
          </button>
        </div>
      </div>
      
      <div className="flex-1 bg-black relative flex items-center justify-center">
        <video 
          src={videoUrl} 
          controls 
          autoPlay 
          loop 
          className="w-full h-full object-contain"
        />
      </div>

      <div className="p-4 bg-slate-900/80 backdrop-blur-md flex items-center justify-between absolute bottom-0 left-0 right-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
        <span className="text-sm text-slate-300">High Quality Render</span>
        <a 
          href={videoUrl}
          download="nova-ai-video.mp4"
          target="_blank"
          rel="noreferrer"
          className="btn-primary py-2 px-4 text-sm"
        >
          <SafeIcon icon={FiIcons.FiDownload} /> Download MP4
        </a>
      </div>
    </motion.div>
  );
};

export default VideoPreview;