import React, { useCallback } from 'react';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const UploadPanel = ({ file, setFile }) => {
  const handleDrop = useCallback((e) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type.startsWith('image/')) {
      setFile(droppedFile);
    }
  }, [setFile]);

  const handleChange = (e) => {
    if (e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  return (
    <div className="mb-6">
      <label className="flex items-center gap-2 text-sm font-medium text-slate-300 mb-3">
        <SafeIcon icon={FiIcons.FiImage} className="text-sky-400" />
        Initial Image (Optional)
      </label>
      
      {!file ? (
        <div 
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          className="border-2 border-dashed border-slate-700 bg-slate-900/30 rounded-xl p-6 text-center hover:border-sky-500/50 hover:bg-sky-500/5 transition-all cursor-pointer group"
          onClick={() => document.getElementById('file-upload').click()}
        >
          <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
            <SafeIcon icon={FiIcons.FiUploadCloud} className="text-slate-400 group-hover:text-sky-400 text-xl" />
          </div>
          <p className="text-sm text-slate-300 font-medium">Click or drag image here</p>
          <p className="text-xs text-slate-500 mt-1">Supports JPG, PNG (Max 10MB)</p>
          <input 
            id="file-upload" 
            type="file" 
            accept="image/*" 
            className="hidden" 
            onChange={handleChange}
          />
        </div>
      ) : (
        <div className="relative rounded-xl overflow-hidden border border-slate-700 bg-slate-900 aspect-video flex items-center justify-center">
          <img 
            src={URL.createObjectURL(file)} 
            alt="Preview" 
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
            <button 
              onClick={() => setFile(null)}
              className="bg-red-500/80 text-white px-4 py-2 rounded-lg flex items-center gap-2 backdrop-blur-sm hover:bg-red-500 transition-colors"
            >
              <SafeIcon icon={FiIcons.FiTrash2} /> Remove
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default UploadPanel;