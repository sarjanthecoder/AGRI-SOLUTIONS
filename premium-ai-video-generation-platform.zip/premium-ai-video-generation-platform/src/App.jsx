import React from 'react';
import ParticlesBackground from './components/ParticlesBackground';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Generator from './components/Generator';

function App() {
  return (
    <div className="min-h-screen relative selection:bg-sky-500/30 selection:text-sky-200">
      <ParticlesBackground />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <Generator />
      </main>
    </div>
  );
}

export default App;