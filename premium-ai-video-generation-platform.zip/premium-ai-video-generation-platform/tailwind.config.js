/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'nova-dark': '#020617',
        'nova-panel': 'rgba(15, 23, 42, 0.6)',
        'nova-border': 'rgba(56, 189, 248, 0.2)',
        'nova-glow': 'rgba(56, 189, 248, 0.5)',
      },
      boxShadow: {
        'glow': '0 0 20px rgba(56, 189, 248, 0.3)',
        'glow-strong': '0 0 30px rgba(56, 189, 248, 0.6)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        }
      }
    },
  },
  plugins: [],
}