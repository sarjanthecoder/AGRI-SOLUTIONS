import express from 'express';
import multer from 'multer';
import { generateVideoController } from '../controllers/videoController.js';

const router = express.Router();

// Configure multer for memory storage
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

router.post('/generate', upload.single('image'), generateVideoController);

export default router;