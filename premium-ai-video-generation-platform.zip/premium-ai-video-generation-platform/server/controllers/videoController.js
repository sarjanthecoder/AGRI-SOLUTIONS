import { generateVideo } from '../services/falService.js';

export const generateVideoController = async (req, res) => {
  try {
    const { prompt, model, settings } = req.body;
    const file = req.file;

    if (!prompt) {
      return res.status(400).json({ success: false, error: 'Prompt is required' });
    }

    if (!process.env.FAL_KEY) {
      return res.status(500).json({ 
        success: false, 
        error: 'FAL_KEY is not configured in the environment variables.' 
      });
    }

    let imageBase64 = null;
    if (file) {
      const b64 = Buffer.from(file.buffer).toString('base64');
      imageBase64 = `data:${file.mimetype};base64,${b64}`;
    }

    const parsedSettings = settings ? JSON.parse(settings) : {};

    // Start generation
    console.log(`Starting generation with model: ${model}`);
    const result = await generateVideo(prompt, model, imageBase64, parsedSettings);

    res.status(200).json({
      success: true,
      data: result
    });

  } catch (error) {
    console.error('Generation Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to generate video'
    });
  }
};