import { fal } from "@fal-ai/client";

// Map our frontend models to FAL endpoints
const MODEL_ENDPOINTS = {
  'kling': {
    t2v: 'fal-ai/kling-video/v1/standard/text-to-video',
    i2v: 'fal-ai/kling-video/v1/standard/image-to-video'
  },
  'hunyuan': {
    t2v: 'fal-ai/hunyuan-video',
    i2v: 'fal-ai/hunyuan-video' // Assuming same or fallback
  },
  'wan': {
    t2v: 'fal-ai/wan-v1/text-to-video',
    i2v: 'fal-ai/wan-v1/text-to-video'
  },
  'pixverse': {
    t2v: 'fal-ai/pixverse/v3/text-to-video',
    i2v: 'fal-ai/pixverse/v3/image-to-video'
  },
  'veo': {
    // Placeholder using Luma as alternative if Veo isn't directly available, 
    // but using a realistic fal endpoint structure
    t2v: 'fal-ai/luma-dream-machine', 
    i2v: 'fal-ai/luma-dream-machine/image-to-video'
  }
};

export const generateVideo = async (prompt, modelName, imageBase64, settings) => {
  const modelKey = modelName.toLowerCase();
  const endpoints = MODEL_ENDPOINTS[modelKey] || MODEL_ENDPOINTS['kling'];
  
  const isImageToVideo = !!imageBase64;
  const endpoint = isImageToVideo ? endpoints.i2v : endpoints.t2v;

  const input = {
    prompt,
    ...settings
  };

  if (isImageToVideo) {
    input.image_url = imageBase64;
  }

  try {
    // Using fal.subscribe for long-running tasks
    const result = await fal.subscribe(endpoint, {
      input,
      logs: true,
      onQueueUpdate: (update) => {
        if (update.status === "IN_PROGRESS") {
          console.log("Generation in progress...", update.logs);
        }
      }
    });

    // Extract video URL based on common FAL response structures
    const videoUrl = result.video?.url || result.url || (result.data && result.data[0]?.url);
    
    if (!videoUrl) {
      throw new Error("No video URL returned from API");
    }

    return {
      videoUrl,
      model: modelName,
      status: 'completed'
    };
  } catch (error) {
    console.error("FAL API Error:", error);
    throw new Error(`FAL API Error: ${error.message}`);
  }
};